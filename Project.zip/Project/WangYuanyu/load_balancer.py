import threading, time, socket, json, sys, hashlib

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        # Forward request to backend (YOU must implement logic)
        response = forward_to_backend(data, addr[0])

        # Send backend response back to correct client
        client_sock.sendall(response)

    finally:
        client_sock.close()   

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================

rr_counter = 0
rr_lock = threading.Lock()
BACKEND_NODES = [('20.0.0.3', 6000), ('20.0.0.4', 6000), ('20.0.0.5', 6000)]
BACKEND_NAMES = {'20.0.0.3': 'b1', '20.0.0.4': 'b2', '20.0.0.5': 'b3'}

def forward_to_backend(data, client_ip):
    global rr_counter
    
    with rr_lock:
        backend_ip, backend_port = BACKEND_NODES[rr_counter]
        rr_counter = (rr_counter + 1) % len(BACKEND_NODES)

    try:
        request_obj = json.loads(data.decode('utf-8'))
        request_obj['client_ip'] = client_ip
        backend_payload = json.dumps(request_obj).encode('utf-8')
    except Exception as e:
        return b'{"error": "Invalid JSON request"}'

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as be_sock:
            be_sock.connect((backend_ip, backend_port))
            be_sock.sendall(backend_payload)
            backend_response_bytes = be_sock.recv(4096)
            
        response_obj = json.loads(backend_response_bytes.decode('utf-8'))
        be_ip = response_obj.get('backend_ip', backend_ip)
        
        final_response = {
            "vertex_count": response_obj.get("vertex_count"),
            "req_id": response_obj.get("req_id"),
            "client_ip": response_obj.get("client_ip"),
            "backend": BACKEND_NAMES.get(be_ip, "UNKNOWN")
        }
        
        return json.dumps(final_response).encode('utf-8')
        
    except Exception as e:
        return b'{"error": "Backend connection failed"}'

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)