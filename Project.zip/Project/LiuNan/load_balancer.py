import threading, time, socket, json, sys, hashlib

BACKENDS = [
    {"name": "b1", "ip": "20.0.0.3", "port": 6000},
    {"name": "b2", "ip": "20.0.0.4", "port": 6000},
    {"name": "b3", "ip": "20.0.0.5", "port": 6000}
]

rr_index = 0
rr_lock = threading.Lock()

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        client_ip = addr[0]

        # Forward request to backend (YOU must implement logic)
        response = forward_to_backend(data, client_ip)

        # Send backend response back to correct client
        if response:
            client_sock.sendall(response)

    except Exception as e:
        print(f"[LB] Client handler error: {e}")
    finally:
        client_sock.close()   

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================
def forward_to_backend(data, client_ip):
    global rr_index
    
    try:
        request_data = json.loads(data.decode())
        with rr_lock:
            backend = BACKENDS[rr_index]
            rr_index = (rr_index + 1) % len(BACKENDS)

        request_data['client_ip'] = client_ip
        backend_payload = (json.dumps(request_data) + "\n").encode()

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as be_sock:
            be_sock.connect((backend['ip'], backend['port']))

            be_sock.sendall(backend_payload)

            be_response_data = be_sock.recv(8192)
            
            if not be_response_data:
                return None
            

            resp_json = json.loads(be_response_data.decode())
            resp_json.pop('backend_ip', None)
            resp_json['backend'] = backend['name']
            
            return json.dumps(resp_json).encode()

    except Exception as e:
        print(f"[LB] Forwarding error: {e}")
        return None

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2]) # 端口必须转为整数
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)
