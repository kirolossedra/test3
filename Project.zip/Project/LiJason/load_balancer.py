import threading, time, socket, json, sys, hashlib

BACKENDS = [
    {"name": "b1", "ip": "20.0.0.3", "port": 6000},
    {"name": "b2", "ip": "20.0.0.4", "port": 6000},
    {"name": "b3", "ip": "20.0.0.5", "port": 6000},
]

rr_lock = threading.Lock()
rr_index = 0

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        # Forward request to backend (YOU must implement logic)
        response = forward_to_backend(data, addr[0])

        # Send backend response back to correct client
        client_sock.sendall(response)

    finally:
        client_sock.close()

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================
def forward_to_backend(data, client_ip):
    global rr_index

    try:
        req = json.loads(data.decode().strip())
        request_id = req.get("request_id")
        graph = req.get("graph", {})

        with rr_lock:
            backend = BACKENDS[rr_index]
            rr_index = (rr_index + 1) % len(BACKENDS)

        payload_to_backend = {
            "client_ip": client_ip,
            "request_id": request_id,
            "graph": graph
        }

        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.connect((backend["ip"], backend["port"]))
            s.sendall(json.dumps(payload_to_backend).encode())
            backend_response_bytes = s.recv(4096)

        backend_response = json.loads(backend_response_bytes.decode().strip())
        backend_ip = backend_response.get("backend_ip")

        backend_name = "UNKNOWN"
        for b in BACKENDS:
            if b["ip"] == backend_ip:
                backend_name = b["name"]
                break

        response_to_client = {
            "backend": backend_name,
            "vertex_count": backend_response.get("vertex_count"),
            "client_ip": backend_response.get("client_ip"),
            "request_id": backend_response.get("request_id")
        }

        return json.dumps(response_to_client).encode()

    except Exception as e:
        error_response = {
            "backend": "UNKNOWN",
            "vertex_count": None,
            "client_ip": client_ip,
            "request_id": None,
            "error": str(e)
        }
        return json.dumps(error_response).encode()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)