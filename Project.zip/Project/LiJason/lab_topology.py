from mininet.net import Mininet
from mininet.topo import Topo
from mininet.node import Node, OVSSwitch
from mininet.cli import CLI
from mininet.link import TCLink
from mininet.node import RemoteController
from mininet.log import setLogLevel, info

from mininet.node import Node

class LoadBalancerTopo(Topo):
    def build(self, delay = '0ms'):
        # -------------------------------------------------
        # TODO STUDENTS:
        # Create hosts h1, h2, h3 (Done)
        # Create backend hosts b1, b2, b3 (Done)
        # Create switches s1 and s2
        # Create load balancer node (Done)
        # Assign IP addresses exactly as specified
        # -------------------------------------------------

        # IMPORTANT:
        # DO NOT rename hosts
        # DO NOT change interface names
        # Grader depends on exact naming
        # -------------------------------------------------
        
        # Network 1 (Left-hand Network)
        # hX = Clients
        h1 = self.addHost(name="h1", ip="10.0.0.2/24")
        h2 = self.addHost(name="h2", ip="10.0.0.3/24")
        h3 = self.addHost(name="h3", ip="10.0.0.4/24")

        # Network 2 (Right-hand Network)
        # bX = Back-End Servers
        b1 = self.addHost(name="b1", ip="20.0.0.3/24")
        b2 = self.addHost(name="b2", ip="20.0.0.4/24")
        b3 = self.addHost(name="b3", ip="20.0.0.5/24")

        # Load Balancer
        lb = self.addHost(name="lb", ip=None)

        s1 = self.addSwitch(name="s1")
        s2 = self.addSwitch(name="s2")

        self.addLink(h1, s1, delay = delay)
        self.addLink(h2, s1, delay = delay)
        self.addLink(h3, s1, delay = delay)
        self.addLink(b1, s2, delay = delay)
        self.addLink(b2, s2, delay = delay)
        self.addLink(b3, s2, delay = delay)

        self.addLink(lb, s1, intfName1 = "lb-eth0", params1 = {"ip": "10.0.0.9/24"}, delay = delay)
        self.addLink(lb, s2, intfName1 = "lb-eth1", params1 = {"ip": "20.0.0.2/24"}, delay = delay)

if __name__ == '__main__':
    topology = LoadBalancerTopo()
    network = Mininet(topo=topology, link=TCLink, controller=lambda name:RemoteController(name, p='127.0.0.1', port=6633))
    network.start()
    network.get('b1').cmd('route add -host 10.0.0.9 gw 20.0.0.2')
    network.get('b2').cmd('route add -host 10.0.0.9 gw 20.0.0.2')
    network.get('b3').cmd('route add -host 10.0.0.9 gw 20.0.0.2')
    CLI(network)
    network.stop()
