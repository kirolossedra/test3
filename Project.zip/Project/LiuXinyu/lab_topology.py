from mininet.net import Mininet
from mininet.topo import Topo
from mininet.node import Node, OVSSwitch
from mininet.cli import CLI
from mininet.link import TCLink
from mininet.node import RemoteController
from mininet.log import setLogLevel, info

from mininet.node import Node

class LoadBalancerTopo(Topo):
    def build(self, delay = '0ms'):
        # -------------------------------------------------
        # TODO STUDENTS:
        # Create hosts h1, h2, h3 (Done)
        # Create backend hosts b1, b2, b3 (Done)
        # Create switches s1 and s2
        # Create load balancer node (Done)
        # Assign IP addresses exactly as specified
        # -------------------------------------------------

        # IMPORTANT:
        # DO NOT rename hosts
        # DO NOT change interface names
        # Grader depends on exact naming
        # -------------------------------------------------

        # Create switches s1 and s2
        s1 = self.addSwitch(name="s1")
        s2 = self.addSwitch(name="s2")
        
        # Network 1 (Left-hand Network)
        # hX = Clients
        h1 = self.addHost(name="h1")
        h2 = self.addHost(name="h2")
        h3 = self.addHost(name="h3")

        # Network 2 (Right-hand Network)
        # bX = Back-End Servers
        b1 = self.addHost(name="b1")
        b2 = self.addHost(name="b2")
        b3 = self.addHost(name="b3")

        # Load Balancer
        lb = self.addHost(name="lb") 

        # Add links between switches and hosts
        self.addLink(h1, s1)
        self.addLink(h2, s1)
        self.addLink(h3, s1)
        self.addLink(b1, s2)
        self.addLink(b2, s2)
        self.addLink(b3, s2)
        self.addLink(lb, s1)
        self.addLink(lb, s2)

if __name__ == '__main__':
    topology = LoadBalancerTopo()
    network = Mininet(topo=topology, link=TCLink, controller=lambda name:RemoteController(name, p='127.0.0.1', port=6633))
    network.start()

    lb = network.get('lb')
    h1, h2, h3 = network.get('h1', 'h2', 'h3')
    b1, b2, b3 = network.get('b1', 'b2', 'b3')

    # Configure client IP
    h1.setIP('10.0.0.2', prefixLen=24, intf='h1-eth0')
    h2.setIP('10.0.0.3', prefixLen=24, intf='h2-eth0')
    h3.setIP('10.0.0.4', prefixLen=24, intf='h3-eth0')

    # Configure backend server IP
    b1.setIP('20.0.0.3', prefixLen=24, intf='b1-eth0')
    b2.setIP('20.0.0.4', prefixLen=24, intf='b2-eth0')
    b3.setIP('20.0.0.5', prefixLen=24, intf='b3-eth0')

    # Configure load balancer dual-network card IP
    lb.setIP('10.0.0.9', prefixLen=24, intf='lb-eth0')
    lb.setIP('20.0.0.2', prefixLen=24, intf='lb-eth1')

    # Network isolation: restrict each node to its own subnet only
    for node in [h1, h2, h3]:
        node.cmd('ip route flush table main')
        node.cmd('ip route add 10.0.0.0/24 dev %s-eth0' % node.name)

    for node in [b1, b2, b3]:
        node.cmd('ip route flush table main')
        node.cmd('ip route add 20.0.0.0/24 dev %s-eth0' % node.name)

    lb.cmd('sysctl -w net.ipv4.ip_forward=0')  # lb acts as app-layer proxy, not IP router (Learned this from https://man7.org/linux/man-pages/man8/sysctl.8.html)

    CLI(network)

    network.stop()
