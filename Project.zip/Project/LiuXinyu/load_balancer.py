import threading, time, socket, json, sys, hashlib

# Thread-safe round-robin counter
rr_index = 0
rr_lock = threading.Lock()
# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        client_ip = addr[0]
        response = forward_to_backend(data, client_ip)

        # Send backend response back to correct client
        client_sock.sendall(response)

    finally:
        client_sock.close()

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================
def forward_to_backend(data, client_ip):
    global rr_index

    request = json.loads(data.decode().strip())
    req_id = request.get("req_id", "unknown")
    graph = request.get("graph", {})

    # Round-robin backend selection
    ips = ['20.0.0.3', '20.0.0.4', '20.0.0.5']
    names = ['b1', 'b2', 'b3']
    port = 6000

    with rr_lock:
        index = rr_index % 3
        rr_index += 1

    ip = ips[index]
    name = names[index]

    lb_to_backend_msg = json.dumps({
        "client_ip": client_ip,
        "req_id": req_id,
        "graph": graph
    })

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((ip, port))
        s.sendall(lb_to_backend_msg.encode())
        backend_raw = s.recv(4096).decode()

    response = json.loads(backend_raw)

    client_response = json.dumps({
        "backend": name,
        "vertex_count": response.get("vertex_count"),
        "client_ip": response.get("client_ip", client_ip),
        "req_id": response.get("req_id", req_id)
    })

    return client_response.encode()


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)