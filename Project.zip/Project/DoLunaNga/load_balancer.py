import threading, socket, json, sys, os

# ---------------------------
# Backend configuration
# ---------------------------
BACKENDS = [
    ("20.0.0.3", 6000),  # b1
    ("20.0.0.4", 6000),  # b2
    ("20.0.0.5", 6000),  # b3
]
BACKEND_NAME = {
    ("20.0.0.3", 6000): "b1",
    ("20.0.0.4", 6000): "b2",
    ("20.0.0.5", 6000): "b3",
}
# Allow override from environment (set in start_servers.cli)
env_backends = os.getenv("LB_BACKENDS")
if env_backends:
    pairs = []
    for p in env_backends.split(","):
        ip, port = p.strip().split(":")
        pairs.append((ip, int(port)))
    BACKENDS = pairs
    env_names = os.getenv("LB_BACKEND_NAMES")
    if env_names:
        names = [n.strip() for n in env_names.split(",")]
        BACKEND_NAME = {BACKENDS[i]: names[i] for i in range(min(len(BACKENDS), len(names)))}

# ---------------------------
# Round-robin state
# ---------------------------
_rr_lock = threading.Lock()
_rr_index = 0

def rr_select():
    global _rr_index
    with _rr_lock:
        backend = BACKENDS[_rr_index]
        _rr_index = (_rr_index + 1) % len(BACKENDS)
    return backend

# ---------------------------
# Helpers
# ---------------------------
def recv_all(sock, chunk=65536):
    """Receive until peer closes write side."""
    buf = bytearray()
    while True:
        part = sock.recv(chunk)
        if not part:
            break
        buf.extend(part)
        if len(part) < chunk:
            # try to drain remaining bytes briefly
            sock.settimeout(0.05)
            try:
                more = sock.recv(chunk)
                if more:
                    buf.extend(more)
            except Exception:
                pass
            break
    return bytes(buf)

def safe_json_loads(data_bytes):
    return json.loads(data_bytes.decode("utf-8"))

def to_bytes(obj):
    return json.dumps(obj, separators=(",", ":")).encode("utf-8")

# =========================================================
# DO NOT MODIFY THIS METHOD (from your template)
# =========================================================


def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((lb_ip, lb_port))
    server.listen(64)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        print("[LB] Waiting for client...", flush=True)
        client_sock, addr = server.accept()
        print(f"[LB] Accepted connection from {addr}", flush=True)
        threading.Thread(target=client_handler, args=(client_sock, addr), daemon=True).start()


# =========================================================
# CLIENT CONNECTION HANDLER
# =========================================================
def client_handler(client_sock, addr):
    try:
        data = client_sock.recv(4096)
        if not data:
            return
        response = forward_to_backend(data, addr)
        client_sock.sendall(response)
    except Exception as e:
        # Return a JSON error so the client can print it
        try:
            client_sock.sendall(to_bytes({"error": f"LB client_handler exception: {e}"}))
        except Exception:
            pass
    finally:
        try:
            client_sock.shutdown(socket.SHUT_RDWR)
        except Exception:
            pass
        client_sock.close()

# =========================================================
# FORWARD TO BACKEND (ROUND-ROBIN, THREAD-SAFE)
# =========================================================
def forward_to_backend(data, client_addr):
    # Parse client request
    try:
        payload = safe_json_loads(data)
    except Exception as e:
        return to_bytes({"error": f"Malformed JSON from client: {e}"})

    request_id = payload.get("request_id")
    client_ip  = payload.get("client_ip") or (client_addr[0] if client_addr else None)
    graph_data = payload.get("graph_data")

    if request_id is None or client_ip is None or graph_data is None:
        return to_bytes({"error": "Missing fields: client_ip, request_id, graph_data"})

    to_backend = {"client_ip": client_ip, "request_id": request_id, "graph_data": graph_data}
    outbound = to_bytes(to_backend)

    attempts = 0
    last_exc = None
    while attempts < len(BACKENDS):
        backend_ip, backend_port = rr_select()
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as bs:
                bs.settimeout(5.0)
                bs.connect((backend_ip, backend_port))
                bs.sendall(outbound)
                try:
                    bs.shutdown(socket.SHUT_WR)
                except Exception:
                    pass
                backend_bytes = recv_all(bs)

            # Parse backend response
            try:
                bresp = safe_json_loads(backend_bytes)
            except Exception as pe:
                last_exc = pe
                attempts += 1
                continue

            vertex_count = bresp.get("vertex_count")
            resp_client  = bresp.get("client_ip")
            resp_id      = bresp.get("request_id")
            # Optional field the backend returns:
            resp_backend_ip = bresp.get("backend_ip", backend_ip)

            if resp_id != request_id or resp_client != client_ip or vertex_count is None:
                last_exc = ValueError("Backend response failed contract check")
                attempts += 1
                continue

            backend_name = BACKEND_NAME.get((backend_ip, backend_port), "UNKNOWN")
            to_client = {
                "backend": backend_name,
                "vertex_count": vertex_count,
                "client_ip": client_ip,
                "request_id": request_id
            }
            return to_bytes(to_client)

        except Exception as e:
            last_exc = e
            attempts += 1
            continue

    # If all backends failed
    return to_bytes({
        "error": f"All backends unreachable or invalid responses: {type(last_exc).__name__}: {last_exc}",
        "client_ip": client_ip,
        "request_id": request_id
    })

# ---------------------------
# Main
# ---------------------------
if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)
    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)