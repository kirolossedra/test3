#!/usr/bin/env python3
"""
lab_topology.py

Two-armed load balancer topology for Mininet, with a built-in test runner that
implements the "Suggested Testing Strategy" (Steps 1 -> 6).

Addressing (from the diagram):
  lb-eth0 (left / clients side)  = 10.0.0.9/24   (gateway for h1–h3)
  lb-eth1 (right / backends side)= 20.0.0.2/24   (gateway for b1–b3)

Clients (left via s1):
  h1 = 10.0.0.2/24  gw 10.0.0.9
  h2 = 10.0.0.3/24  gw 10.0.0.9
  h3 = 10.0.0.4/24  gw 10.0.0.9

Backends (right via s2):
  b1 = 20.0.0.3/24  gw 20.0.0.2
  b2 = 20.0.0.4/24  gw 20.0.0.2
  b3 = 20.0.0.5/24  gw 20.0.0.2

Controller: POX (remote) at 127.0.0.1:6633
- Keep EXACT node names: h1,h2,h3,b1,b2,b3,lb,s1,s2 
- Do NOT hardcode application ports; the diagram’s :5000/:6000 are app-level.

To run the test:
Shell# Terminal A
sudo systemctl restart openvswitch-switch
python3 /opt/pox/pox.py openflow.of_01 --port=6633 forwarding.l2_learning

Shell# Terminal B
sudo mn -c
sudo python3 lab_topology.py

"""

import re
import sys
import argparse
from mininet.net import Mininet
from mininet.topo import Topo
from mininet.node import OVSSwitch, RemoteController
from mininet.cli import CLI
from mininet.link import TCLink
from mininet.log import setLogLevel, info

# ------------------ Address plan ------------------
LB_IP = {
    'left':  '10.0.0.9/24',   # lb-eth0 towards clients (s1 side)
    'right': '20.0.0.2/24',   # lb-eth1 towards backends (s2 side)
}

HOST_CFG = {
    # Left/clients side (s1)
    'h1': {'ip': '10.0.0.2/24', 'gw': '10.0.0.9'},
    'h2': {'ip': '10.0.0.3/24', 'gw': '10.0.0.9'},
    'h3': {'ip': '10.0.0.4/24', 'gw': '10.0.0.9'},
    # Right/backends side (s2)
    'b1': {'ip': '20.0.0.3/24', 'gw': '20.0.0.2'},
    'b2': {'ip': '20.0.0.4/24', 'gw': '20.0.0.2'},
    'b3': {'ip': '20.0.0.5/24', 'gw': '20.0.0.2'},
}

# Controller settings (fixed in script, per handout convention)
CTRL_IP   = '127.0.0.1'
CTRL_PORT = 6633
# ---------------------------------------------------

class LoadBalancerTopo(Topo):
    def build(self, delay='0ms'):
        """
        Wiring (names must remain exactly as is):
          h1 h2 h3 -- s1 -- lb-eth0      lb-eth1 -- s2 -- b1 b2 b3
        """
        # Clients
        h1 = self.addHost('h1')
        h2 = self.addHost('h2')
        h3 = self.addHost('h3')
        # Backends
        b1 = self.addHost('b1')
        b2 = self.addHost('b2')
        b3 = self.addHost('b3')
        # Load balancer with two NICs
        lb = self.addHost('lb')
        # Switches
        s1 = self.addSwitch('s1')
        s2 = self.addSwitch('s2')

        # Client links
        self.addLink(h1, s1, cls=TCLink, delay=delay)
        self.addLink(h2, s1, cls=TCLink, delay=delay)
        self.addLink(h3, s1, cls=TCLink, delay=delay)

        # Backend links
        self.addLink(b1, s2, cls=TCLink, delay=delay)
        self.addLink(b2, s2, cls=TCLink, delay=delay)
        self.addLink(b3, s2, cls=TCLink, delay=delay)

        # lb’s NIC names are fixed so graders can rely on them
        self.addLink(lb, s1, cls=TCLink, delay=delay, intfName1='lb-eth0')
        self.addLink(lb, s2, cls=TCLink, delay=delay, intfName1='lb-eth1')


# ------------------ Network configuration ------------------

def configure_network(net):
    """Assign IPs/routes exactly; enable routing on lb."""
    # Configure lb two interfaces
    lb = net.get('lb')
    lb_if_left, lb_if_right = 'lb-eth0', 'lb-eth1'

    lb.cmd(f'ip addr flush dev {lb_if_left}')
    lb.cmd(f'ip addr add {LB_IP["left"]} dev {lb_if_left}')
    lb.cmd(f'ip link set {lb_if_left} up')

    lb.cmd(f'ip addr flush dev {lb_if_right}')
    lb.cmd(f'ip addr add {LB_IP["right"]} dev {lb_if_right}')
    lb.cmd(f'ip link set {lb_if_right} up')

    # Enable IPv4 forwarding (lb routes between subnets)
    lb.cmd('sysctl -w net.ipv4.ip_forward=1')

    # Configure hosts (IP + default route)
    for hname, cfg in HOST_CFG.items():
        h = net.get(hname)
        intf = f'{hname}-eth0'
        h.cmd(f'ip addr flush dev {intf}')
        h.cmd(f'ip addr add {cfg["ip"]} dev {intf}')
        h.cmd(f'ip link set {intf} up')
        h.cmd('ip route del default || true')
        h.cmd(f'ip route add default via {cfg["gw"]}')
        info(f'Configured {hname}: {cfg["ip"]} gw {cfg["gw"]}\n')

    # Ensure POX compatibility (OpenFlow 1.0)
    for sw in net.switches:
        sw.cmd(f'ovs-vsctl set bridge {sw.name} protocols=OpenFlow10')


# ------------------ Suggested Testing Strategy (Steps 1 → 6) ----------

def _host_has_ifconfig(h):
    return 'ifconfig' in h.cmd('which ifconfig || true')

def _print_ifconfig_or_ip(hname, net):
    h = net.get(hname)
    intf = f'{hname}-eth0' if hname != 'lb' else 'lb-eth0'
    # For lb we print both NICs
    if hname == 'lb':
        cmds = []
        if _host_has_ifconfig(h):
            cmds = ['ifconfig lb-eth0', 'ifconfig lb-eth1']
        else:
            cmds = ['ip addr show dev lb-eth0', 'ip addr show dev lb-eth1']
        for cmd in cmds:
            out = h.cmd(cmd)
            info(f'\n[{hname}] {cmd}\n{out}\n')
    else:
        cmd = f'ifconfig {intf}' if _host_has_ifconfig(h) else f'ip addr show dev {intf}'
        out = h.cmd(cmd)
        info(f'\n[{hname}] {cmd}\n{out}\n')

def _ping_once(net, src, dst, timeout=2):
    out = net.get(src).cmd(f'ping -c1 -W{timeout} {dst}')
    ok = (' 0% packet loss' in out) or (' 0.0% packet loss' in out) or (' 1 received' in out)
    return ok, out

def run_suggested_testing_strategy(net, expect_isolation=False):
    """
    Sections:
      • STEP 1: ifconfig/ip for h1,h2,h3,b1,b2,b3,lb (lb shows both NICs)
      • STEP 2: check connectivity between hosts (clients on the left)
      • STEP 3: check connectivity between host and load balancer (clients -> lb-eth0)
      • STEP 4: check connectivity between backends (servers on the right)
      • STEP 5: check connectivity between backend and load balancer (b1 -> lb-eth0)
      • STEP 6: check connectivity between backend and host (h1 -> b1)
    """
    def has_ifconfig(node):
        return 'ifconfig' in node.cmd('which ifconfig || true')

    def print_ifcfg_for(hostname):
        h = net.get(hostname)
        if hostname == 'lb':
            # Print both lb-eth0 and lb-eth1
            if has_ifconfig(h):
                cmds = ['ifconfig lb-eth0', 'ifconfig lb-eth1']
            else:
                cmds = ['ip addr show dev lb-eth0', 'ip addr show dev lb-eth1']
            for cmd in cmds:
                out = h.cmd(cmd)
                info(f'\n[{hostname}] {cmd}\n{out}\n')
        else:
            intf = f'{hostname}-eth0'
            cmd = f'ifconfig {intf}' if has_ifconfig(h) else f'ip addr show dev {intf}'
            out = h.cmd(cmd)
            info(f'\n[{hostname}] {cmd}\n{out}\n')

    def show(cmd_label, out):
        # Print the prompt-like label, then the raw ping output
        info(f'\n{cmd_label}\n')
        info(out + ('' if out.endswith('\n') else '\n'))

    # Resolve LB IPs (strip CIDR)
    lb_left_ip  = LB_IP['left'].split('/')[0]   # lb-eth0 = 10.0.0.9
    lb_right_ip = LB_IP['right'].split('/')[0]  # lb-eth1 = 20.0.0.2

    # ---------- STEP 1: ifconfig/ip for ALL nodes ----------
    info('\n• STEP 1: Check IP addresses with ifconfig/ip:\n')
    for n in ['h1', 'h2', 'h3', 'b1', 'b2', 'b3', 'lb']:
        print_ifcfg_for(n)

    # ---------- STEP 2: check connectivity between hosts (clients on the left) ----------
    info('\n• Between hosts (clients on the left): \n')
    out = net.get('h1').cmd('ping -c3 -W2 10.0.0.3')  # h1 -> h2
    show('mininet> h1 ping h2', out)

    out = net.get('h2').cmd('ping -c3 -W2 10.0.0.4')  # h2 -> h3
    show('mininet> h2 ping h3', out)

    out = net.get('h3').cmd('ping -c3 -W2 10.0.0.2')  # h3 -> h1
    show('mininet> h3 ping h1', out)

    # ---------- STEP 3: check connectivity between host and load balancer (clients -> lb-eth0) ----------
    info('\n• Between host and load balancer:\n')
    out = net.get('h1').cmd(f'ping -c3 -W2 {lb_left_ip}')  # h1 -> lb-eth0 (10.0.0.9)
    show('mininet> h1 ping lb', out)

    # ---------- STEP 4: check connectivity between backends (servers) ----------
    info('\n• Between backends:\n')
    out = net.get('b1').cmd('ping -c3 -W2 20.0.0.4')  # b1 -> b2
    show('mininet> b1 ping b2', out)

    out = net.get('b2').cmd('ping -c3 -W2 20.0.0.5')  # b2 -> b3
    show('mininet> b2 ping b3', out)

    out = net.get('b3').cmd('ping -c3 -W2 20.0.0.3')  # b3 -> b1
    show('mininet> b3 ping b1', out)

    # ---------- STEP 5: check connectivity between backend and load balancer (servers -> lb-eth0) ----------
    info('\n• Between backend and load balancer:\n')
    out = net.get('b1').cmd(f'ping -c3 -W2 {lb_left_ip}')  # b1 -> lb-eth0 (10.0.0.9)
    show('mininet> b1 ping lb', out)

    # ---------- STEP 6: check connectivity between backend and host (client <-> backend example) ----------
    info('\n• Between backend and host:\n')
    out = net.get('h1').cmd('ping -c3 -W2 20.0.0.3')  # h1 -> b1
    show('mininet> h1 ping b1', out)
# ------------------ Entrypoint ------------------

def parse_args():
    ap = argparse.ArgumentParser(description='Load balancer topology with Suggested Testing Strategy (Steps 1–6)')
    ap.add_argument('--delay', default='0ms', help='optional link delay for all links (e.g., 5ms)')
    ap.add_argument('--expect-isolation', action='store_true',
                    help='treat client<->backend pings as FAIL (use only if you enforced isolation policy)')
    return ap.parse_args()

def main():
    args = parse_args()
    setLogLevel('info')

    topo = LoadBalancerTopo(delay=args.delay)
    net = Mininet(
        topo=topo,
        link=TCLink,
        controller=lambda name: RemoteController(name, ip=CTRL_IP, port=CTRL_PORT),
        switch=OVSSwitch,
        autoSetMacs=True,
        autoStaticArp=False
    )

    net.start()
    configure_network(net)

    # Run the Suggested Testing Strategy (Steps 1 -> 6)
    run_suggested_testing_strategy(net, expect_isolation=args.expect_isolation)

    info('\n*** Entering Mininet CLI (type exit to stop)\n')
    CLI(net)
    net.stop()

if __name__ == '__main__':
    main()