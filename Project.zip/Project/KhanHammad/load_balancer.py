import threading, socket, json, sys

# List of backend servers
BACKENDS = [
    ("20.0.0.3", 6000, "b1"),
    ("20.0.0.4", 6000, "b2"),
    ("20.0.0.5", 6000, "b3")
]
# round robin index & lock
rr_idx = 0
rr_lock = threading.Lock()

def recv_chunk(sock):
    sock.settimeout(5.0)
    data = b""
    while True:
        try:
            chunk = sock.recv(4096)
            if not chunk:
                break
            data += chunk
            if b"\n" in data:
                break
        except socket.timeout:
            break
    return data.strip()

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = recv_chunk(client_sock)
        if not data:
            return

        
        # send client ip aswell in the payload
        request = json.loads(data.decode())
        request["client_ip"] = addr[0]
        data = json.dumps(request).encode()

        # Forward request to backend (YOU must implement logic)
        response = forward_to_backend(data)

        # Send backend response back to correct client
        client_sock.sendall(response)

    finally:
        client_sock.close()   

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================
def forward_to_backend(data):
    # Backend round robin selection
    global rr_idx

    with rr_lock:
        backend_ip, backend_port, backend_name = BACKENDS[rr_idx]
        rr_idx = (rr_idx + 1) % len(BACKENDS)

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            payload = data
            s.connect((backend_ip, backend_port))
            s.sendall(payload + b"\n")
            # decode response to set backend name before sending it back to the client
            backend_response = json.loads(recv_chunk(s).decode())
            # get backend IP to set backend name
            backend_ip = backend_response.get("backend_ip", "UNKNOWN")
            # construct client response
            client_response = {
                "vertex_count": backend_response.get("vertex_count", -1), # fallback since 0 is a valid return
                "req_id": backend_response.get("req_id", "UNKNOWN"),
                "client_ip": backend_response.get("client_ip", "UNKNOWN"),
                "backend": backend_name
            }
            return (json.dumps(client_response) + "\n").encode()
    except Exception as  e:
        print(f"[LB] Backend {backend_name} unreachable {e}")
        return (json.dumps({
            "vertex_count": -1,
            "req_id": "UNKNOWN",
            "client_ip": "UNKNOWN",
            "backend": backend_name
            }) + "\n").encode()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)