import threading, time, socket, json, sys, hashlib

backend_servers = [
    ("20.0.0.3", 6000),
    ("20.0.0.4", 6000),
    ("20.0.0.5", 6000),
]

backend_name_map = {
    "20.0.0.3": "b1",
    "20.0.0.4": "b2",
    "20.0.0.5": "b3",
}

rr_index = 0
rr_lock = threading.Lock()

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        data = client_sock.recv(4096)
        if not data:
            return

        response = forward_to_backend(data, addr)

        client_sock.sendall(response)

    except Exception as e:
        print(f"[LB client_handler ERROR] {e}", flush=True)
        try:
            client_sock.sendall(json.dumps({"error": "load balancer error"}).encode())
        except:
            pass
    finally:
        client_sock.close()

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================
def forward_to_backend(data, client_addr):
    global rr_index

    try:
        client_request = json.loads(data.decode())
    except Exception:
        return json.dumps({"error": "invalid client json"}).encode()

    req_id = client_request.get("req_id", "")
    graph = client_request.get("graph", {})
    client_ip = client_addr[0]

    with rr_lock:
        backend = backend_servers[rr_index]
        rr_index = (rr_index + 1) % len(backend_servers)

    backend_ip, backend_port = backend

    backend_payload = {
        "client_ip": client_ip,
        "req_id": req_id,
        "graph": graph
    }

    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.connect((backend_ip, backend_port))
        s.sendall(json.dumps(backend_payload).encode())

        response = s.recv(4096)
        s.close()

        backend_response = json.loads(response.decode())

        backend_ip_from_response = backend_response.get("backend_ip", backend_ip)
        vertex_count = backend_response.get("vertex_count")
        client_ip_from_response = backend_response.get("client_ip", client_ip)
        req_id_from_response = backend_response.get("req_id", req_id)

        final_response = {
            "vertex_count": vertex_count,
            "req_id": req_id_from_response,
            "client_ip": client_ip_from_response,
            "backend": backend_name_map.get(backend_ip_from_response, "UNKNOWN")
        }

        return json.dumps(final_response).encode()

    except Exception as e:
        print("[LB ERROR]", e, flush=True)
        return json.dumps({
            "error": "backend failure",
            "req_id": req_id,
            "client_ip": client_ip
        }).encode()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)