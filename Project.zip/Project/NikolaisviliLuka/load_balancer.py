# Luka Nikolaisvili - 21174826
# University of Waterloo - ECE 610 - Project - Load Balancer Implementation

#Importing necessary libraries for the use of threading, socket programming, JSON handling, and system operations.
import threading
import socket
import json
import sys


BACKENDS = [ #We hardcode backend IPs and ports since they are static in our Mininet topology; in a real system, we would have service discovery instead of hardcoding
    {"name": "b1", "ip": "20.0.0.3", "port": 6000},
    {"name": "b2", "ip": "20.0.0.4", "port": 6000},
    {"name": "b3", "ip": "20.0.0.5", "port": 6000},
] # this is the list of dictionaries representing our backend servers; each dictionary has the keys "name", "ip", and "port"
_rr_lock    = threading.Lock()
_rr_counter = 0


def _get_next_backend():
    """ Select the next backend server in a thread-safe round-robin manner.

    Returns:
        dict[str, str | int]: a dictionary with keys "name", "ip", and "port" representing the next backend server to use, selected in a thread-safe round-robin manner
    """
    global _rr_counter # global variable to keep track of the next backend index for the RR
    with _rr_lock:
        backend = BACKENDS[_rr_counter % len(BACKENDS)] # select the backend based on the current value of the counter modulo the number of backends
        _rr_counter += 1 # Increment the counter for the next call; which will ensure that the next call to this function will get the next backend available
    return backend #return the backend dictionary that we have selected for this request


def recvall(sock):
    """ Read until EOF (sender closed write end). Returns bytes.

    Args:
        sock (obj): this socket is expected to be connected and the sender will shut down its write end after sending, so this method reads until EOF.

    Returns:
        bytes: the following method returns bytes, which can be decoded by the caller
    """
    chunks = []
    while True: #infinite loop until we see EOF (sender closed write end)
        chunk = sock.recv(4096) #recv returns bytes; returns b'' on EOF
        if not chunk: # if chunk is empty, we have seen EOF, so we break out of the loop
            break # if we have seen EOF, we break out of the loop and return what we have so far
        chunks.append(chunk) # if we have data, we append it to our list of chunks and keep reading
    return b''.join(chunks) # once we have seen EOF, we join all the chunks together and return the full message as bytes



# DO NOT MODIFY THIS METHOD
def start_load_balancer(lb_ip, lb_port):
    """Start the load balancer server to listen for client connections and handle them.

    Args:
        lb_ip (int): _description_
        lb_port (int): _description_
    """
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()



# CLIENT CONNECTION HANDLER
def client_handler(client_sock, addr):
    """ Handle a single client connection: receive request, forward to backend, send response.

    Args:
        client_sock (obj):  this socket is connected to the client and we will read the client's request from it and send the response back through it
        addr (obj):  the client's address (IP and port) as a tuple; we can use addr[0] to get the client's IP address as a string, which we will forward to the backend
    """
    try:
        # Receive full request from client (client shuts down write end)
        data = recvall(client_sock)
        if not data: #if the data is empty, this means that the client has closed the connection without sending any response.
            return # return nothing

        client_ip = addr[0] # get the first element of the addr tuple, which is the client's IP address as a string; we will forward this to the backend so it can include it in its response

        response = forward_to_backend(data, client_ip) # forward the client's request data and IP address to the backend and get the response that we should send back to the client; this method will handle selecting the backend, forwarding the request, and translating the response
        client_sock.sendall(response) # send the response back to the client; response is expected to be bytes, which is what sendall requires

    except Exception as e: # handel the exceptions that may occur during the handling of the client connection, such as JSON parsing errors
        print(f"[LB] client_handler error: {e}", flush=True)
    finally: # in the finally block, we close the client socket to clean up the connection.
        client_sock.close()



# ROUND-ROBIN FORWARD TO BACKEND
def forward_to_backend(data, client_ip):
    """ Forward the client's request to a backend server and return the backend's response, after translating it.     

    Args:
        data (obj): The client's request data as bytes
        client_ip (str): The client's IP address as a string

    Returns:
        bytes: The translated response from the backend as bytes
    """
    #Select backend using round-robin which is thread safe since we may have multiple client_handler threads calling this function
    backend = _get_next_backend()

    # parse the client's request, which is expected to be JSON with at least the key "graph";
    try:
        request = json.loads(data.decode().strip()) 
    except json.JSONDecodeError as e: #handing JSON parsing errors that may occur if the client sends malformed JSON
        print(f"[LB] JSON parse error: {e}", flush=True) # print the error to the console for debugging purposes 
        return json.dumps({"error": "bad request"}).encode() # return a JSON error response to the client indicating that the request was bad


    request["client_ip"] = client_ip #  requires the backend to report the client's IP address in its response
    payload = json.dumps(request).encode() #we create the payload, which is the JSON-encoded request that we will forward to the backend

    
    try: #Excepton handling for errors that may occur during the forwarding to the backend, such as connection errors or JSON parsing errors.
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock: # we create a new socket to connect to the backend; we use a with statement to ensure that the socket is properly closed after we are done with it
            sock.connect((backend["ip"], backend["port"])) # connect to the backend using the IP and port from the selected backend dictionary
            sock.sendall(payload) # send the payload to the backend
            sock.shutdown(socket.SHUT_WR)  #EOF flag
            raw_response = recvall(sock) # read the full response from the backend until it closes the connection
    except Exception as e: #catch the exceptions that may occur and print an appropriate error message to the console for debugging purposes.
        print(f"[LB] Backend error ({backend['name']}): {e}", flush=True)
        return json.dumps({"error": "backend unavailable"}).encode() # return a JSON error response to the client indicating that the backend is unavailable

   
    try: # we expect the backend's response to be JSON with at least the key "vertex_count"; we also add the backend's name to the response for logging purposes
        response = json.loads(raw_response.decode())
        response["backend"] = backend["name"] # add the backend's name to the response for logging purposes
        response.pop("backend_ip", None) # remove the backend_ip from the response before sending it to the client
    except json.JSONDecodeError as e: # handle JSON parsing errors that may occur if the backend sends a malformed response
        print(f"[LB] Backend response parse error: {e}", flush=True) # print the error to the console for debugging purposes
        return json.dumps({"error": "bad backend response"}).encode() # return a JSON error response to the client indicating that the backend response was bad

    print( # log the request and response details to the console for debugging purposes; this includes the request ID, client IP, backend name, and vertex count from the response
        f"[LB] req_id={response.get('req_id','?')} "
        f"client={client_ip} -> {backend['name']} "
        f"vertices={response.get('vertex_count','?')}",
        flush=True # ensure that the log is printed immediately without buffering
    )
    return json.dumps(response).encode() # return the backend's response as JSON-encoded bytes to be sent back to the client


if __name__ == "__main__": #flow of the execution when we run this script; we expect the user to provide the load balancer's IP address and port as command-line arguments 
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1) #if the arguments were not provided correcrtly, then we are going to exit the program with the status code 1.

    lb_ip  = sys.argv[1] #otherwise, we get the user-provided arguments as the load balancers ip address
    lb_port = int(sys.argv[2]) # and the port number.
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port) #imediately we start the load balancer by calling the method for the load balancer, with the provided arguments.