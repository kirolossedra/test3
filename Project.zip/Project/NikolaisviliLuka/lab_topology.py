# Luka Nikolaisvili - 21174826
# University of Waterloo - ECE 610 - Project - Load Balancer Implementation

from mininet.net import Mininet
from mininet.topo import Topo
from mininet.node import OVSSwitch
from mininet.cli import CLI
from mininet.link import TCLink
from mininet.node import RemoteController
from mininet.log import setLogLevel, info


class LoadBalancerTopo(Topo):
    """ Custom Mininet topology for the load balancer project, consisting of two subnets

    Args:
        Topo (obj): this class inherits from the Mininet Topo class, which provides methods for building network topologies in Mininet
    """
    def build(self, delay='0ms'):
        """ Build the custom topology with two subnets

        Args:
            delay (str, optional): The delay for the links. Defaults to '0ms'.
        """

        # Network 1 — 10.0.0.0/24
        # h(1-3) = Clients connected to switch s1
        h1 = self.addHost('h1', ip='10.0.0.2/24') #Add host h1 with IP address
        h2 = self.addHost('h2', ip='10.0.0.3/24') #Add host h2 with IP address
        h3 = self.addHost('h3', ip='10.0.0.4/24')# Add host h3 with IP address

        
        # Network 2 — 20.0.0.0/24
        # b(1-3) = Back-End Servers connected to switch s2
        b1 = self.addHost('b1', ip='20.0.0.3/24')# Add host b1 with IP address
        b2 = self.addHost('b2', ip='20.0.0.4/24') # Add host b2 with IP address
        b3 = self.addHost('b3', ip='20.0.0.5/24') # Add host b3 with IP address

      
        # Load Balancer — bridges both networks
        # eth0: 10.0.0.9/24 (clients via s1)
        # eth1: 20.0.0.2/24 (backends via s2)
        # ip sets the address on the first interface (eth0)
       
        lb = self.addHost('lb', ip='10.0.0.9/24') # Add host lb with IP address (eth0 will be

     
        # Switches
        s1 = self.addSwitch('s1') # Add switch s1 for the first subnet (clients)
        s2 = self.addSwitch('s2') # Add switch s2 for the second subnet (backends)

        # Links: clients -- s1, backends -- s2
        self.addLink(h1, s1) # Add a link between host h1 and switch s1
        self.addLink(h2, s1) # Add a link between host h2 and switch s1
        self.addLink(h3, s1) # Add a link between host h3 and switch s1

       
        # Links: lb -- s1 (becomes lb-eth0), lb -- s2 (becomes lb-eth1)
        # first link = eth0, second link = eth1
        self.addLink(lb, s1)   # lb-eth0  -- 10.0.0.9/24 (set by ip above)
        self.addLink(lb, s2)   # lb-eth1  -- 20.0.0.2/24 (configured below)

        # Links: backends -- s2
        self.addLink(b1, s2) # Add a link between host b1 and switch s2
        self.addLink(b2, s2) # Add a link between host b2 and switch s2
        self.addLink(b3, s2) # Add a link between host b3 and switch s2


if __name__ == '__main__':
    setLogLevel('info')

    topology = LoadBalancerTopo() # Create an instance of the LoadBalancerTopo class to build the custom topology
    network = Mininet( 
        topo=topology, # Use the custom topology defined by the LoadBalancerTopo class
        link=TCLink, # Use the TCLink class for links, which allows for traffic control.
        switch=OVSSwitch, # Use the OVSSwitch class for switches.
        controller=lambda name: RemoteController(name, ip='127.0.0.1', port=6633) # Use a remote controller running on localhost at port 6633
    )
    network.start() # Start the Mininet network based on the defined topology

   
    # Configure lb-eth1 (Mininet only auto-assigns ip= to first interface)
    lb = network.get('lb') # Get the load balancer host object from the Mininet network
    lb.cmd('ip addr flush dev lb-eth1') # Flush any existing IP address configuration on the lb-eth1 interface
    lb.cmd('ip addr add 20.0.0.2/24 dev lb-eth1') # Assign the IP address
    lb.cmd('ip link set lb-eth1 up') # Bring up the lb-eth1 interface to make it active
    lb.cmd('ip link set lb-eth0 up') # Bring up the lb-eth0 interface to make it active (should already be up, but just in case)

    # backends cannot reach 10.0.0.x by default, but we flush just in case Mininet added one
    for hostname in ['h1', 'h2', 'h3']: # Iterate through each client host (h1, h2, h3) to configure their routing
        host = network.get(hostname) # Get the host object for each client host (h1, h2, h3) from the Mininet network
        host.cmd('ip route del default 2>/dev/null; true') # Delete any existing default route configuration.

   
    # Backends need a default gateway via lb-eth1 (20.0.0.2) so that
    # "b1 ping lb" (which resolves to 10.0.0.9) can be routed through
    # the load balancer — matching the expected output.
    for hostname in ['b1', 'b2', 'b3']:
        backend = network.get(hostname)
        backend.cmd('ip route del default 2>/dev/null; true')
        backend.cmd('ip route add default via 20.0.0.2')

    # Enable IP forwarding on lb so it can route between the two subnets
    lb.cmd('sysctl -w net.ipv4.ip_forward=1')

    info('*** Topology ready. Use CLI to test.\n')
    info('*** Tests:\n')
    info('    h1 ping h2          (should succeed)\n')
    info('    h1 ping lb          (should succeed — lb is 10.0.0.9)\n')
    info('    b1 ping b2          (should succeed)\n')
    info('    b1 ping lb          (should succeed — lb eth1 is 20.0.0.2)\n')
    info('    h1 ping b1          (should FAIL )\n')

    CLI(network)
    network.stop()
