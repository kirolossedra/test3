import threading, time, socket, json, sys, hashlib


# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        # Forward request to backend (YOU must implement logic)
        response = forward_to_backend(data, addr[0])

        # Send backend response back to correct client
        client_sock.sendall(response)

    finally:
        client_sock.close()   

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin (Done)
#   2. Open TCP connection to backend (Done)
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================

BACKENDS = ["20.0.0.3", "20.0.0.4", "20.0.0.5"]
BACKEND_PORT = 6000
BACKEND_NAMES = {"20.0.0.3": "b1", "20.0.0.4": "b2", "20.0.0.5": "b3"}
rr_lock = threading.Lock()
rr_index = 0

def forward_to_backend(data, client_ip):
    # Round robin
    global rr_index
    with rr_lock:
        backend_ip = BACKENDS[rr_index]
        rr_index = (rr_index + 1) % len(BACKENDS)
    
    req = json.loads(data.decode())
    req["client_ip"] = client_ip

    # Open TCP 
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as b_sock:
        b_sock.connect((backend_ip, BACKEND_PORT))
        b_sock.sendall(json.dumps(req).encode())
        b_resp_data = b_sock.recv(4096)

        if not b_resp_data:
            return b""

    b_resp = json.loads(b_resp_data.decode())
    b_resp["backend"] = BACKEND_NAMES.get(backend_ip, "UNKNOWN")
    return json.dumps(b_resp).encode()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)