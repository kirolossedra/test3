import threading, time, socket, json, sys, hashlib

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        # Forward request to backend (YOU must implement logic)
        response = forward_to_backend(data, addr)

        # Send backend response back to correct client
        client_sock.sendall(response)

    finally:
        client_sock.close()   

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================

backend_servers = [
    ("b1", "20.0.0.3"),
    ("b2", "20.0.0.4"),
    ("b3", "20.0.0.5")
]
ip_to_backend_name = {ip: name for name, ip in backend_servers}

backend_index = 0
lock = threading.Lock()

def forward_to_backend(data, addr):
    global backend_index

    with lock:
        backend_name, backend_ip = backend_servers[backend_index]
        backend_index = (backend_index + 1) % len(backend_servers)

    backend_port = 6000  

    #add "client_ip"
    request = json.loads(data.decode().strip())
    request["client_ip"] = addr[0] #addr = (ip, port)
    payload = json.dumps(request) + "\n"

    #Create the socket connection
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.connect((backend_ip, backend_port))
        # s.sendall(data)
        s.sendall(payload.encode())
        response = s.recv(4096)

    #Rebuild the reponse to client
    backend_response = json.loads(response.decode().strip())
    payload_to_client = {
        "vertex_count": backend_response["vertex_count"],
        "req_id": backend_response["req_id"],
        "client_ip": backend_response["client_ip"],
        "backend": ip_to_backend_name[backend_response["backend_ip"]]}
    
    return (json.dumps(payload_to_client) + "\n").encode()



if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)