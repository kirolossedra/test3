from mininet.net import Mininet
from mininet.topo import Topo
from mininet.node import Node, OVSSwitch
from mininet.cli import CLI
from mininet.link import TCLink
from mininet.node import RemoteController
from mininet.log import setLogLevel, info

from mininet.node import Node

class LoadBalancerTopo(Topo):
    def build(self, delay = '0ms'):
        # -------------------------------------------------
        # Create hosts h1, h2, h3 (Done)
        # Create backend hosts b1, b2, b3 (Done)
        # Create switches s1 and s2
        # Create load balancer node (Done)
        # Assign IP addresses exactly as specified
        # -------------------------------------------------

        # IMPORTANT:
        # DO NOT rename hosts
        # DO NOT change interface names
        # Grader depends on exact naming
        # -------------------------------------------------
        
        # Network 1 (Left-hand Network)
        # hX = Clients
        h1 = self.addHost(name="h1", ip="10.0.0.2/24", defaultRoute="via 10.0.0.9")
        h2 = self.addHost(name="h2", ip="10.0.0.3/24", defaultRoute="via 10.0.0.9")
        h3 = self.addHost(name="h3", ip="10.0.0.4/24", defaultRoute="via 10.0.0.9")

        # Network 2 (Right-hand Network)
        # bX = Back-End Servers
        b1 = self.addHost(name="b1", ip="20.0.0.3/24", defaultRoute="via 20.0.0.2")
        b2 = self.addHost(name="b2", ip="20.0.0.4/24", defaultRoute="via 20.0.0.2")
        b3 = self.addHost(name="b3", ip="20.0.0.5/24", defaultRoute="via 20.0.0.2")

        # Load Balancer
        lb = self.addHost(name="lb") 

        # Switches
        s1 = self.addSwitch("s1")
        s2 = self.addSwitch("s2")

        # Links
        self.addLink(h1, s1)
        self.addLink(h2, s1)
        self.addLink(h3, s1)
        self.addLink(lb, s1)

        self.addLink(lb, s2)
        self.addLink(b1, s2)
        self.addLink(b2, s2)
        self.addLink(b3, s2)

if __name__ == '__main__':
    setLogLevel('info')
    topology = LoadBalancerTopo()
    network = Mininet(topo=topology, link=TCLink, controller=lambda name:RemoteController(name, ip='127.0.0.1', port=6633))
    network.start()

    # Configure load balancer IP addresses
    lb = network.get('lb')
    lb.cmd('ifconfig lb-eth0 10.0.0.9 netmask 255.255.255.0')
    lb.cmd('ifconfig lb-eth1 20.0.0.2 netmask 255.255.255.0')

    # Disable IP forwarding on lb to enforce network isolation
    lb.cmd('sysctl -w net.ipv4.ip_forward=0')

    CLI(network)

    network.stop()
