import threading, time, socket, json, sys, hashlib, uuid

# Thread-safe round robin state
BACKENDS = [("20.0.0.3", 6000), ("20.0.0.4", 6000), ("20.0.0.5", 6000)]
BACKEND_NAMES = {"20.0.0.3": "b1", "20.0.0.4": "b2", "20.0.0.5": "b3"}
rr_lock = threading.Lock()
rr_index = 0

def get_next_backend():
    global rr_index
    with rr_lock:
        backend = BACKENDS[rr_index]
        rr_index = (rr_index + 1) % len(BACKENDS)
        return backend

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        # Extract client IP
        client_ip = addr[0]

        # Forward request to backend (YOU must implement logic)
        response = forward_to_backend(data, client_ip)

        # Send backend response back to correct client
        client_sock.sendall(response)

    finally:
        client_sock.close()   

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================
def forward_to_backend(data, client_ip):
    # 1. Select backend using round robin (thread-safe via rr_lock)
    backend_ip, backend_port = get_next_backend()
    backend_name = BACKEND_NAMES.get(backend_ip, "unknown")

    # Parse the client request
    req = json.loads(data.decode())

    # The teacher's client.py does NOT send a req_id.
    # We generate one here if absent so the contract is always satisfied.
    req_id = req.get("req_id") or uuid.uuid4().hex

    # Communication Contract: LB -> Backend: client_ip, req_id, graph
    backend_payload = json.dumps({
        "client_ip": client_ip,
        "req_id": req_id,
        "graph": req.get("graph", {})
    }).encode()

    # 2 & 3. Open TCP connection to selected backend and forward request
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as b_sock:
        b_sock.connect((backend_ip, backend_port))
        b_sock.sendall(backend_payload)

        # 4. Receive response from backend
        # Teacher's backend only returns {"vertex_count": N} — that is fine.
        # We fill in all other contract fields from what we already know here.
        b_resp_data = b_sock.recv(4096)

    b_resp = json.loads(b_resp_data.decode())

    # 5. Communication Contract: LB -> Client: backend, vertex_count, client_ip, req_id
    # backend_name and req_id are already known to us.
    # client_ip is echoed back if the backend supports it, else we use ours.
    final_resp = {
        "backend": backend_name,
        "vertex_count": b_resp.get("vertex_count"),
        "client_ip": b_resp.get("client_ip", client_ip),
        "req_id": b_resp.get("req_id", req_id)
    }

    return (json.dumps(final_resp) + "\n").encode()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)