import threading, time, socket, json, sys, hashlib

# Thread-safe round robin state
BACKENDS = [("20.0.0.3", 6000), ("20.0.0.4", 6000), ("20.0.0.5", 6000)]
BACKEND_NAMES = {"20.0.0.3": "b1", "20.0.0.4": "b2", "20.0.0.5": "b3"}
rr_lock = threading.Lock()
rr_index = 0

def get_next_backend():
    global rr_index
    with rr_lock:
        backend = BACKENDS[rr_index]
        rr_index = (rr_index + 1) % len(BACKENDS)
        return backend

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        # Extract client IP
        client_ip = addr[0]

        # Forward request to backend (YOU must implement logic)
        response = forward_to_backend(data, client_ip)

        # Send backend response back to correct client
        client_sock.sendall(response)

    finally:
        client_sock.close()   

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================
def forward_to_backend(data, client_ip):
    # 1. Select backend using round robin
    backend_ip, backend_port = get_next_backend()

    # Add client_ip to request payload
    req = json.loads(data.decode())
    req["client_ip"] = client_ip
    backend_req_data = json.dumps(req).encode()

    # 2 & 3. Open TCP connection to backend and forward request
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as b_sock:
        b_sock.connect((backend_ip, backend_port))
        b_sock.sendall(backend_req_data)
        
        # 4. Receive response
        b_resp_data = b_sock.recv(4096)
        
    # Format response back to client (Step 5)
    b_resp = json.loads(b_resp_data.decode())
    b_ip = b_resp.get("backend_ip")
    
    final_resp = {
        "backend": BACKEND_NAMES.get(b_ip, "unknown"),
        "vertex_count": b_resp.get("vertex_count"),
        "client_ip": b_resp.get("client_ip"),
        "req_id": b_resp.get("req_id")
    }

    # Return response bytes
    return (json.dumps(final_resp) + "\n").encode()

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)