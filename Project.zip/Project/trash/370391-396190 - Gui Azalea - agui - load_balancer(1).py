import threading, time, socket, json, sys, hashlib

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
counter = 0
counter_lock = threading.Lock()
backends = [("20.0.0.3", "b1"), ("20.0.0.4", "b2"), ("20.0.0.5", "b3")]
num_backends = len(backends)
backend_port = 6000

def client_handler(client_sock, addr):
    try:
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        # Forward request to backend (YOU must implement logic)
        response_bytes, backend_name = forward_to_backend(data)

        resp_json = json.loads(response_bytes.decode())
        req_json = json.loads(data.decode())
        
        # Add fields
        resp_json["backend"] = backend_name
        resp_json["client_ip"] = addr[0]
        resp_json["request_id"] = req_json.get("request_id")
        
        response = json.dumps(resp_json).encode()

        # Send backend response back to correct client
        client_sock.sendall(response)

    except Exception as e:
        print(f"Error handling client: {e}")
    finally:
        client_sock.close()   

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================
def forward_to_backend(data):
    global counter, counter_lock

    # Rotate backend index
    with counter_lock:
        backend_index = counter
        counter = (counter + 1) % num_backends
    
    backend_ip, backend_name = backends[backend_index]

    # Forward
    backend_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        backend_sock.connect((backend_ip, backend_port))
        backend_sock.sendall(data)
        response = backend_sock.recv(4096)
        return response, backend_name
    except Exception as e:
        print(f"Error forwarding request to backend: {e}")
        return None, backend_name
    finally:
        backend_sock.close()
        

if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    lb_port = int(sys.argv[2])
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)
