import threading, time, socket, json, sys, hashlib

# =========================================================
# GLOBAL ROUND-ROBIN STATE
# ---------------------------------------------------------
# Add global variables so all threads share the same counter
# =========================================================

# The list of backends in order, round-robin cycles through these
BACKENDS = [
    ("20.0.0.3", 6000),   # b1
    ("20.0.0.4", 6000),   # b2
    ("20.0.0.5", 6000),   # b3
]

# Map the backend IP to name for the response
BACKEND_NAMES = {
    "20.0.0.3": "b1",
    "20.0.0.4": "b2",
    "20.0.0.5": "b3",
}

# The current index into BACKENDS for round-robin 
rr_index = 0

# Lock to protect rr_index from race conditions
rr_lock = threading.Lock()

# =========================================================
# DO NOT MODIFY THIS METHOD
# ---------------------------------------------------------
# This function starts the load balancer server.
# It listens for client connections and creates a thread
# for each client.
# =========================================================
def start_load_balancer(lb_ip, lb_port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.bind((lb_ip, lb_port))
    server.listen(1)
    print(f"[LB] Load balancer listening on {lb_ip}:{lb_port}", flush=True)

    while True:
        client_sock, addr = server.accept()

        # Each client must be handled in a separate thread.
        # If you remove threading, concurrent tests will fail.
        threading.Thread(target=client_handler, args=(client_sock, addr)).start()

# YOUR CODE COMES HERE
# =========================================================
# CLIENT CONNECTION HANDLER
# ---------------------------------------------------------
# Receives request from client
# Forwards it to backend
# Sends backend response back to client
# =========================================================
def client_handler(client_sock, addr):
    try:
        # Get client IP from addr
        client_ip = addr[0]
        # Receive client request
        data = client_sock.recv(4096)
        if not data:
            return

        # Parse the incoming JSON to include client_ip before forwarding
        request = json.loads(data.decode().strip())
        request["client_ip"] = client_ip  

        # Forward request to backend (YOU must implement logic)
        response = forward_to_backend(json.dumps(request).encode())

        # Send backend response back to correct client
        client_sock.sendall(response)

    finally:
        client_sock.close()   

# =========================================================
# STUDENTS MUST IMPLEMENT THEIR SOLUTION HERE
# ---------------------------------------------------------
# Responsibilities:
#   1. Select backend using round robin
#   2. Open TCP connection to backend
#   3. Forward request
#   4. Receive response
#   5. Return response bytes
#
# Requirements:
#   - MUST be thread-safe
#   - MUST NOT drop requests
#   - MUST return correct backend response
#   - MUST NOT modify request_id
#
# Common Mistakes:
#   - forgetting locks for round robin counter
#   - returning wrong client response
#   - sending malformed JSON
# =========================================================
def forward_to_backend(data):
    global rr_index
    # 1. Select backend using round-robin 
    with rr_lock:
        # Read current index, then advance it for the next request
        index = rr_index
        rr_index = (rr_index + 1) % len(BACKENDS)

    backend_ip, backend_port = BACKENDS[index]
    print(f"[LB] Forwarding to backend {BACKEND_NAMES[backend_ip]} ({backend_ip}:{backend_port})", flush=True)

    # 2. Open TCP connection to backend
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as backend_sock:
        backend_sock.connect((backend_ip, backend_port))

        # 3. Forward request
        backend_sock.sendall(data)

        # 4. Receive response
        backend_response_raw = backend_sock.recv(4096)

    # 5. Return response bytes
    backend_response = json.loads(backend_response_raw.decode())

    # The backend sends: vertex_count, req_id, client_ip, backend_ip
    # The client expects: vertex_count, req_id, client_ip, backend name
    client_response = json.dumps({"vertex_count": backend_response["vertex_count"],
                                  "req_id": backend_response["req_id"],
                                  "client_ip": backend_response["client_ip"],
                                  "backend": BACKEND_NAMES[backend_response["backend_ip"]]
                                }).encode()

    return client_response


if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Usage: python3 load_balancer.py lb_ip_address lb_port")
        sys.exit(1)

    lb_ip = sys.argv[1]
    # Add int wrapping to resolve integer error
    lb_port = int(sys.argv[2]) 
    start_load_balancer(lb_ip=lb_ip, lb_port=lb_port)