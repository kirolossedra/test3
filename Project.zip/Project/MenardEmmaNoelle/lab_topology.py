from mininet.net import Mininet
from mininet.topo import Topo
from mininet.node import Node, OVSSwitch
from mininet.cli import CLI
from mininet.link import TCLink
from mininet.node import RemoteController
from mininet.log import setLogLevel, info

from mininet.node import Node

class LoadBalancerTopo(Topo):
    def build(self, delay = '0ms'):
        # -------------------------------------------------
        # TODO STUDENTS:
        # Create hosts h1, h2, h3 (Done)
        # Create backend hosts b1, b2, b3 (Done)
        # Create switches s1 and s2
        # Create load balancer node (Done)
        # Assign IP addresses exactly as specified
        # -------------------------------------------------

        # IMPORTANT:
        # DO NOT rename hosts
        # DO NOT change interface names
        # Grader depends on exact naming
        # -------------------------------------------------
        
        # Network 1 (Left-hand Network)
        # hX = Clients
        h1 = self.addHost(name="h1")
        h2 = self.addHost(name="h2")
        h3 = self.addHost(name="h3")

        # Network 2 (Right-hand Network)
        # bX = Back-End Servers
        b1 = self.addHost(name="b1")
        b2 = self.addHost(name="b2")
        b3 = self.addHost(name="b3")

        # Load Balancer
        lb = self.addHost(name="lb") 

        # sX = Switches
        s1 = self.addSwitch('s1')
        s2 = self.addSwitch('s2')

        # Ensure the appropriate connectivity between the network nodes
        self.addLink(h1, s1)
        self.addLink(h2, s1)
        self.addLink(h3, s1)
        self.addLink(b1, s2)
        self.addLink(b2, s2)
        self.addLink(b3, s2)
        self.addLink(lb, s1)
        self.addLink(lb, s2)

if __name__ == '__main__':
    topology = LoadBalancerTopo()
    network = Mininet(topo=topology, link=TCLink, controller=lambda name:RemoteController(name, ip='127.0.0.1', port=6633))
    network.start()
    h1 = network.get('h1')
    h2 = network.get('h2')
    h3 = network.get('h3')
    b1 = network.get('b1')
    b2 = network.get('b2')
    b3 = network.get('b3')
    lb = network.get('lb')
    # Configure network interfaces of the clients (h1, h2, h3)
    h1.cmd('ifconfig h1-eth0 10.0.0.2/24 up')
    h2.cmd('ifconfig h2-eth0 10.0.0.3/24 up')
    h3.cmd('ifconfig h3-eth0 10.0.0.4/24 up')
    # Configure network interfaces of the backend servers (b1, b2, b3)
    b1.cmd('ifconfig b1-eth0 20.0.0.3/24 up')
    b2.cmd('ifconfig b2-eth0 20.0.0.4/24 up')
    b3.cmd('ifconfig b3-eth0 20.0.0.5/24 up')
    # Configure the network interfaces of the load balancers
    lb.cmd('ifconfig lb-eth0 10.0.0.9/24 up')
    lb.cmd('ifconfig lb-eth1 20.0.0.2/24 up')

    # Ensure the appropriate network isolation between the network nodes
    lb.cmd('sysctl -w net.ipv4.ip_forward=0')
    h1.cmd('ip route add default via 10.0.0.9')
    h2.cmd('ip route add default via 10.0.0.9')
    h3.cmd('ip route add default via 10.0.0.9')
    b1.cmd('ip route add default via 20.0.0.2')
    b2.cmd('ip route add default via 20.0.0.2')
    b3.cmd('ip route add default via 20.0.0.2')

    CLI(network)

    network.stop()
